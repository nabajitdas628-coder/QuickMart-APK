# QuickMart

Android shopping app project.

## Build APK with GitHub Actions
1. Open **Actions**.
2. Select **Build QuickMart APK**.
3. Tap **Run workflow**.
4. Wait for the green check.
5. Open the successful run and download the **QuickMart-APK** artifact.

This version does not require `gradlew`, `google-services.json`, Firebase, or Razorpay just to build the basic APK.
